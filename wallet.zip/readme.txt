#  HOW TO RUN: open terminal where  wallet.sh  is saved
 run 1:
   chmod +x wallet.sh
   
 run 2 :
   ./wallet.sh

run 3:
0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80